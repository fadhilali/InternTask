<?php
require('dbconnect.php');
include("authorization.php"); ?>
<html>
<head>
<meta charset="utf-8">
<title>Portal Dashboard</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="container" align="Center">
<p>Welcome to the Sample's Dashboard by Fadhil Ali 2019</p>

<p><a href="index.php">Portal Home</a><p>
<p><a href="insert.php">Insert New Record</a></p>
<p><a href="view.php">View Records</a><p>
<p><a href="logout.php">Portal Logout</a></p>
</div>
</body>
</html>
